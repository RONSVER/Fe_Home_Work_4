"use strict";

// Задача "Возрастная проверка":

let usrAge = prompt('Введите возсраст:');
 if (usrAge >= 18) {
     console.log("Вы совершенно летний!");
 } else {
     console.log("вы не совершенно летний..");
 }

// Задача "Угадай число":

 let usrRnd = Math.round(Math.random() * 10);
 const usrPrompt = prompt('Попробуй угадать число:');
 if (+usrPrompt === usrRnd) {
     console.log('Правильно');
 } else {
     console.log('Не верно');
 }

// Задача "Оценка студента":

 let usrGrade = prompt('Введите вашу оценку: ');
 if (+usrGrade >= 70) {
     console.log('Вы сдали предмет');
 } else {
     console.log("Вы не сдали предмет");
 }

// Задача "Проверка пароля":

 const usrPassword = prompt('Введите пароль');
 if (usrPassword == 'qwerty') {
     console.log('Доступ разрешен');
 } else {
     console.log('Доступ запрещен');
 }

//  Задача "Проверка значения":

 let userInput = prompt("Введите значение:");

  if (userInput == '' || userInput == null) {
   console.log("Значение отсутствует");
 } else {
   console.log("Значение: " + userInput);
 }

// Задача "Проверка на пустую строку":

 let usrString = prompt('Введите строку: ');
 if (usrString.length == 0 ) {
    console.log('Cтрока пуста');
 } else {
     console.log(`Длинна строки: ${usrString.length}`);
 }

// Задача "Определение положительного числа":

 let usrInt = prompt('Введите число: ');
 if (+usrInt > 0) {
     console.log("Число положительное");
 }
 if (+usrInt < 0) {
     console.log("Число отрицательное");
 }
 if (+usrInt === 0) {
     console.log('Число равно нулю');
 }
    
